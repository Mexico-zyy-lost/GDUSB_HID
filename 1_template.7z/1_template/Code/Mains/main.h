

#ifndef __MAIN_H
#define __MAIN_H

#include "gd32f30x.h"
#include "systick.h"
#include "led.h"
#include "key.h"
#include "usart.h"	 
#include <stdio.h>

void system_clock_config(void);

#endif /* __MAIN_H */


