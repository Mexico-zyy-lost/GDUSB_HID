

/*!
    \file    main.c
    \brief  
*/
#include "main.h"
#include "standard_hid_core.h"
#include "usbd_hw.h"

usb_dev usb_hid;

extern hid_fop_handler fop_handler;

void main_tick_1s(void)
{
	gd_led_toggle(LED1);
}

/*!
    \brief    main function
    \param[in]  none
    \param[out] none
    \retval     none
*/

int main(void)
{	
    systick_config();
	/* system clocks configuration */
    rcu_config();

    gd_led_init(LED1);
	gd_led_init(LED2);
	gd_key_init(KEY_USER, KEY_MODE_GPIO);
//    gd_com_init(COM0,115200U);
//	printf("Aeliy technology\r\n");
//	printf("Pioneer GD32F303RCT6 core board test\r\n");
	hid_itfop_register (&usb_hid, &fop_handler);

    /* USB device configuration */
    usbd_init(&usb_hid, &hid_desc, &hid_class);

    /* NVIC configuration */
    nvic_config();

    usbd_connect(&usb_hid);
	
	while(USBD_CONFIGURED != usb_hid.cur_status){
    }
	
	while(1)
	{
		/* check whether the button is pressed */
		if(RESET == gd_key_state_get(KEY_USER))
		{
			/* delay 10ms for software removing jitter */
			delay_1ms(10);

			/* check whether the button is pressed */
			if(RESET == gd_key_state_get(KEY_USER))
			{
				gd_led_toggle(LED2);
				fop_handler.hid_itf_data_process(&usb_hid);
			}
		}
		
	}
}

void USART0_IRQHandler(void)	
{
    if((RESET != usart_interrupt_flag_get(COM0, USART_INT_FLAG_RBNE)) && 
       (RESET != usart_flag_get(COM0, USART_FLAG_RBNE)))
		{
        com_put_char(usart_data_receive(COM0));
		}		
}



volatile uint32_t msCount = 0;
void SysTick_Handler(void)
{
	delay_decrement();
	if (msCount % 1000 == 0) {
		main_tick_1s();
		msCount = 0;
	}
	msCount++;
}
