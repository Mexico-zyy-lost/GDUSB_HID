先驱者GD32F303RCT6核心板
===========================
该文件用来介绍关于***先驱者GD32F303RCT6核心板***的实验介绍。

****
|TEAM|AELIY|
|---|---|
|Author|Bobby|
|E-mail|737668978@qq.com|
|Online Shop| https://shop258200087.taobao.com/ |
****

# 使用说明

## 实验平台
先驱者GD32F303RCT6核心板
## 实验名称
LED1闪烁+按键中断翻转LED2+串口自发自收
## 实验功能
1. LED1(PC0)闪烁，时间1S翻转;
2. 按键(PB15)中断翻转LED2(PC1);
3. 串口(USART1 PA9 PA10)自发自收;




